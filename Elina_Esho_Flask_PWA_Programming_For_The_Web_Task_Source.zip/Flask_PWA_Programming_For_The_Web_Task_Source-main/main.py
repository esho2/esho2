from flask import Flask, render_template, request
import database_manager as dbHandler

app = Flask(__name__)


@app.route("/index.html", methods=["GET"])
@app.route("/", methods=["POST", "GET"])
def index():
    content = dbHandler.listExtension()  # Function to get content
    total = len(content)
    start = int(request.args.get("start", 0))
    end = int(request.args.get("end", 20))
    end = min(end, total)  # Ensure end does not exceed total

    return render_template(
        "index.html", content=content, start=start, end=end, total=total
    )


@app.route("/add.html", methods=["POST", "GET"])
def add():
    if request.method == "POST":
        email = request.form["email"]
        name = request.form["name"]
        dbHandler.insertContact(email, name)
        return render_template("add.html", message="Thank you for signing up")
    else:
        return render_template("add.html")


@app.route("/search.html", methods=["GET"])
def search():
    query = request.args.get("query")
    results = dbHandler.searchExtension(query)
    return render_template("search.html", results=results)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
