const assets = [
  "/", // Home page
  "static/css/style.css", // CSS file
  "static/js/app.js", // JavaScript file
  "static/images/logo.png", // Logo image
  "static/images/favicon.jpg", // Favicon image
  "static/icons/icon-128x128.png", // Icon for 128x128 resolution
  "static/icons/icon-192x192.png", // Icon for 192x192 resolution
  "static/icons/icon-384x384.png", // Icon for 384x384 resolution
  "static/icons/icon-512x512.png", // Icon for 512x512 resolution
  "static/icons/desktop_screenshot.png", // Desktop screenshot
  "static/icons/mobile_screenshot.png", // Mobile screenshot
];

const CATALOGUE_ASSETS = "catalogue-assets"; // Cache name

// Install event listener to cache assets
self.addEventListener("install", (installEvt) => {
  installEvt.waitUntil(
    caches
      .open(CATALOGUE_ASSETS)
      .then((cache) => {
        console.log(cache);
        cache.addAll(assets); // Add all assets to the cache
      })
      .then(self.skipWaiting()) // Skip waiting for activation
      .catch((e) => {
        console.log(e); // Log any errors during caching
      })
  );
});

// Activate event listener to clean up old caches
self.addEventListener("activate", function (evt) {
  evt.waitUntil(
    caches
      .keys()
      .then((keyList) => {
        return Promise.all(
          keyList.map((key) => {
            if (key === CATALOGUE_ASSETS) {
              // Delete old cache
              console.log("Removed old cache from", key);
              return caches.delete(key);
            }
          })
        );
      })
      .then(() => self.clients.claim()) // Take control of clients immediately
  );
});

// Fetch event listener to serve cached assets when offline
self.addEventListener("fetch", function (evt) {
  evt.respondWith(
    fetch(evt.request).catch(() => {
      // If network request fails
      return caches.open(CATALOGUE_ASSETS).then((cache) => {
        return cache.match(evt.request); // Serve cached version
      });
    })
  );
});
