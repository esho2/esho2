import sqlite3 as sql


def listExtension():
    con = sql.connect("database/data_source.db")
    cur = con.cursor()
    data = cur.execute("SELECT * FROM extension").fetchall()
    con.close()
    return data


def searchExtension(query):
    con = sql.connect("database/data_source.db")
    cur = con.cursor()
    query = f"%{query}%"
    data = cur.execute(
        "SELECT * FROM extension WHERE name LIKE ? OR artist LIKE ?", (query, query)
    ).fetchall()
    con.close()
    return data


def insertContact(email, name):
    con = sql.connect("database/data_source.db")
    cur = con.cursor()
    cur.execute("INSERT INTO contact_list (email,name) VALUES (?,?)", (email, name))
    con.commit()
    con.close()
