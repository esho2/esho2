from flask import Flask, render_template, request
import database_manager as dbHandler

# Create a Flask application instance
app = Flask(__name__)


# Define route for the index page
@app.route("/index.html", methods=["GET"])  # Handles GET requests for "/index.html"
@app.route(
    "/", methods=["POST", "GET"]
)  # Handles both POST and GET requests for the root URL
def index():
    # Fetch content from the database using dbHandler
    content = dbHandler.listExtension()  # Function to retrieve a list of data
    total = len(content)  # Calculate the total number of items
    start = int(request.args.get("start", 0))  # Get the starting index, default to 0
    end = int(request.args.get("end", 20))  # Get the ending index, default to 20
    end = min(end, total)  # Ensure there are only 20 items displayed at a time

    # Render the "index.html" template with the retrieved content and pagination variables
    return render_template(
        "index.html", content=content, start=start, end=end, total=total
    )


# Define route for the add page
@app.route("/add.html", methods=["POST", "GET"])  # Handles both POST and GET requests
def add():
    if request.method == "POST":
        # If the request method is POST, retrieve form data
        email = request.form["email"]  # Get the email value from the form
        name = request.form["name"]  # Get the name value from the form
        dbHandler.insertContact(
            email, name
        )  # Insert the contact details into the database

        # Render the "add.html" template with a success message
        return render_template("add.html", message="Thank you for signing up")
    else:
        # If the request method is GET, render the "add.html" template without a message
        return render_template("add.html")


# Define route for the search page
@app.route("/search.html", methods=["GET"])  # Handles GET requests for the search page
def search():
    # Get the search query from the request arguments
    query = request.args.get("query")
    # Perform a search using the provided query
    results = dbHandler.searchExtension(query)

    # Render the "search.html" template with the search results
    return render_template("search.html", results=results)


# Run the Flask application if this file is executed directly
if __name__ == "__main__":
    app.run(
        debug=False, host="0.0.0.0", port=5000
    )  # Enable debug mode and set the host/port
from flask import Flask, render_template, request
import database_manager as dbHandler

# Create a Flask application instance
app = Flask(__name__)


# Define route for the index page
@app.route("/index.html", methods=["GET"])  # Handles GET requests for "/index.html"
@app.route(
    "/", methods=["POST", "GET"]
)  # Handles both POST and GET requests for the root URL
def index():
    # Fetch content from the database using dbHandler
    content = dbHandler.listExtension()  # Function to retrieve a list of data
    total = len(content)  # Calculate the total number of items
    start = int(request.args.get("start", 0))  # Get the starting index, default to 0
    end = int(request.args.get("end", 20))  # Get the ending index, default to 20
    end = min(
        end, total
    )  # Ensure the end index does not exceed the total number of items

    # Render the "index.html" template with the retrieved content and pagination variables
    return render_template(
        "index.html", content=content, start=start, end=end, total=total
    )


# Define route for the add page
@app.route("/add.html", methods=["POST", "GET"])  # Handles both POST and GET requests
def add():
    if request.method == "POST":
        # If the request method is POST, retrieve form data
        email = request.form["email"]  # Get the email value from the form
        name = request.form["name"]  # Get the name value from the form
        dbHandler.insertContact(
            email, name
        )  # Insert the contact details into the database

        # Render the "add.html" template with a success message
        return render_template("add.html", message="Thank you for signing up")
    else:
        # If the request method is GET, render the "add.html" template without a message
        return render_template("add.html")


# Define route for the search page
@app.route("/search.html", methods=["GET"])  # Handles GET requests for the search page
def search():
    # Get the search query from the request arguments
    query = request.args.get("query")
    # Perform a search using the provided query
    results = dbHandler.searchExtension(query)

    # Render the "search.html" template with the search results
    return render_template("search.html", results=results)


# Run the Flask application if this file is executed directly
if __name__ == "__main__":
    app.run(
        debug=True, host="0.0.0.0", port=5000
    )  # Enable debug mode and set the host/port
